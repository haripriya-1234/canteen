var billAmount=0;
var isSelected=0;
var gVal=0;
function getPrice1(){
var num1=Number(document.getElementById("item1price").textContent);
gVal=num1;
if(frmRestaurant.chkItem1.checked==true){
isSelected=1;
billAmount+=num1;
}else{
billAmount=billAmount-gVal;
isSelected=0;
gVal=0;
}
document.getElementById("billAmount").innerHTML=billAmount;
}
function getPrice2(){
var num1=Number(document.getElementById("item2price").textContent);
gVal=num1;
if(frmRestaurant.chkItem2.checked==true){
isSelected=1;
billAmount+=num1;
}else{
billAmount=billAmount-gVal;
isSelected=0;
gVal=0;
}
document.getElementById("billAmount").innerHTML=billAmount;
}
function getPrice3(){
var num1=Number(document.getElementById("item3price").textContent);
gVal=num1;
if(frmRestaurant.chkItem3.checked==true){
isSelected=1;
billAmount+=num1;
}else{
billAmount=billAmount-gVal;
isSelected=0;
gVal=0;
}
document.getElementById("billAmount").innerHTML=billAmount;
}
function getPrice4(){
var num1=Number(document.getElementById("item4price").textContent);
gVal=num1;
if(frmRestaurant.chkItem4.checked==true){
isSelected=1;
billAmount+=num1;
}else{
billAmount=billAmount-gVal;
isSelected=0;
gVal=0;
}
document.getElementById("billAmount").innerHTML=billAmount;
}
function getPrice5(){
var num1=Number(document.getElementById("item5price").textContent);
gVal=num1;
if(frmRestaurant.chkItem5.checked==true){
isSelected=1;
billAmount+=num1;
}else{
billAmount=billAmount-gVal;
isSelected=0;
gVal=0;
}
document.getElementById("billAmount").innerHTML=billAmount;
}
function getPrice6(){
var num1=Number(document.getElementById("item6price").textContent);
gVal=num1;
if(frmRestaurant.chkItem6.checked==true){
isSelected=1;
billAmount+=num1;
}else{
billAmount=billAmount-gVal;
isSelected=0;
gVal=0;
}
document.getElementById("billAmount").innerHTML=billAmount;
}
var restaurantArray=new Array("Signs","Normas","Eternity","Aurum","Rogo","Rawcanvas","Stemplant","Chillout","Supperclub","Lockhart","Safehouse","Barbiecafe","Conflictkitchen","Princessheart","Niagara");
var bg_image=new Array("url('images/rest1.jpg')","url('images/rest2.jpg')","url('images/rest3.jpg')","url('images/rest4.jpg')","url('images/rest5.jpg')",
"url('images/rest6.jpg')","url('images/rest7.jpg')","url('images/rest8.jpg')","url('images/rest9.jpg')","url('images/rest10.jpg')",
"url('images/rest11.jpg')","url('images/rest12.jpg')","url('images/rest13.jpg')","url('images/rest14.jpg')","url('images/rest15.jpg')");
var tb_color=new Array("Blue","Yellow","red","Pink","Green","Orange","Gold","Purple","Brown","Silver","Maroon","Violet","Gray","Olive","Indigo");
var i=0;
var count= restaurantArray.length;
var menu=new Array(count);
var priceArray=new Array(count);
for (var p=0;p < count;p++){
menu[p]=new Array(6);
}
for(var q=0;q < count;q++){
priceArray[q]=new Array(6);
}
function load(){
document.body.style.backgroundImage=bg_image[i];
document.getElementById("mytable").style.background=tb_color[i];
document.getElementById("restaurant").innerHTML=restaurantArray[i];
document.getElementById("item1").innerHTML=menu[i][0];
document.getElementById("item2").innerHTML=menu[i][1];
document.getElementById("item3").innerHTML=menu[i][2];
document.getElementById("item4").innerHTML=menu[i][3];
document.getElementById("item5").innerHTML=menu[i][4];
document.getElementById("item6").innerHTML=menu[i][5];
document.getElementById("item1price").innerHTML=priceArray[i][0];
document.getElementById("item2price").innerHTML=priceArray[i][1];
document.getElementById("item3price").innerHTML=priceArray[i][2];
document.getElementById("item4price").innerHTML=priceArray[i][3];
document.getElementById("item5price").innerHTML=priceArray[i][4];
document.getElementById("item6price").innerHTML=priceArray[i][5];
}

function clear_data(){
document.getElementById("frmRestaurant").reset();
billAmount=0
document.getElementById("billAmount").innerHTML=billAmount;
}
function next(){
i++;
if(i==count){
alert("no values after this");
return;
}
clear_data();
load();
}
function previous(){
i--;
if(i<0){
alert("no values before");
return;
}
clear_data()
load();
}
menu[0][0]="veg biryani";
menu[0][1]="chicken biryani";
menu[0][2]="mutton biryani";
menu[0][3]="panner biryani";
menu[0][4]="mushroom biryani";
menu[0][5]="egg biryani";

menu[1][0]="dosa";
menu[1][1]="ragi dosa";
menu[1][2]="masala dosa";
menu[1][3]="spl dosa";
menu[1][4]="upma dosa";
menu[1][5]="ghee dosa";

menu[2][0]="idli";
menu[2][1]="ragi idli";
menu[2][2]="masala idli";
menu[2][3]="spl idli";
menu[2][4]="upma idli";
menu[2][5]="ghee idli";


menu[3][0]="puri";
menu[3][1]="vada";
menu[3][2]="upma";
menu[3][3]="dosa";
menu[3][4]="idli";
menu[3][5]="upma dosa";


menu[4][0]="veg bullets";
menu[4][1]="chicken bullets";
menu[4][2]="mutton bullets";
menu[4][3]="panner bullets";
menu[4][4]="mushroom bullets";
menu[4][5]="egg bullets";


menu[5][0]="veg rice";
menu[5][1]="chicken rice";
menu[5][2]="mutton rice";
menu[5][3]="panner rice";
menu[5][4]="mushroom rice";
menu[5][5]="egg rice";

menu[6][0]="ghee rice";
menu[6][1]="alu rice";
menu[6][2]="cashew rice";
menu[6][3]="veg rice";
menu[6][4]="egg rice";
menu[6][5]="mushroom rice";

menu[7][0]="veg bullets";
menu[7][1]=" dosa";
menu[7][2]="mutton bullets";
menu[7][3]="vada";
menu[7][4]="mushroom bullets";
menu[7][5]="egg bullets";

menu[8][0]="veg bullets";
menu[8][1]="chicken bullets";
menu[8][2]="mutton bullets";
menu[8][3]="veg biryani";
menu[8][4]="mushroom bullets";
menu[8][5]="puri";

menu[9][0]="veg bullets";
menu[9][1]="chicken bullets";
menu[9][2]="mutton biryani";
menu[9][3]="panner bullets";
menu[9][4]="mushroom bullets";
menu[9][5]="egg biryani";

menu[10][0]="veg bullets";
menu[10][1]="chicken biryani";
menu[10][2]="kaju spl biryani";
menu[10][3]="panner bullets";
menu[10][4]="mushroom bullets";
menu[10][5]="egg biryani";

menu[11][0]="veg bullets";
menu[11][1]="chicken bullets";
menu[11][2]="mutton biryani";
menu[11][3]="panner biryani";
menu[11][4]="mushroom bullets";
menu[11][5]="egg biryani";

menu[12][0]="veg bullets";
menu[12][1]="chicken biryani";
menu[12][2]="mutton biryani";
menu[12][3]="panner bullets";
menu[12][4]="mushroom biryani";
menu[12][5]="egg biryani";

menu[13][0]="veg bullets";
menu[13][1]="chicken bullets";
menu[13][2]="mutton biryani";
menu[13][3]="panner rice";
menu[13][4]="mushroom bullets";
menu[13][5]="egg biryani";

menu[14][0]="dosa";
menu[14][1]="chicken bullets";
menu[14][2]="mutton biryani";
menu[14][3]="panner bullets";
menu[14][4]="mushroom bullets";
menu[14][5]="egg biryani";

priceArray[0][0]=100;
priceArray[0][1]=200;
priceArray[0][2]=300;
priceArray[0][3]=400;
priceArray[0][4]=400;
priceArray[0][5]=500;

priceArray[1][0]=100;
priceArray[1][1]=200;
priceArray[1][2]=300;
priceArray[1][3]=400;
priceArray[1][4]=400;
priceArray[1][5]=500;

priceArray[2][0]=100;
priceArray[2][1]=200;
priceArray[2][2]=300;
priceArray[2][3]=400;
priceArray[2][4]=400;
priceArray[2][5]=500;

priceArray[3][0]=100;
priceArray[3][1]=200;
priceArray[3][2]=300;
priceArray[3][3]=400;
priceArray[3][4]=400;
priceArray[3][5]=500;

priceArray[4][0]=100;
priceArray[4][1]=200;
priceArray[4][2]=300;
priceArray[4][3]=400;
priceArray[4][4]=400;
priceArray[4][5]=500;

priceArray[5][0]=100;
priceArray[5][1]=200;
priceArray[5][2]=300;
priceArray[5][3]=400;
priceArray[5][4]=400;
priceArray[5][5]=500;

priceArray[6][0]=100;
priceArray[6][1]=200;
priceArray[6][2]=300;
priceArray[6][3]=400;
priceArray[6][4]=400;
priceArray[6][5]=500;

priceArray[7][0]=100;
priceArray[7][1]=200;
priceArray[7][2]=300;
priceArray[7][3]=400;
priceArray[7][4]=400;
priceArray[7][5]=500;

priceArray[8][0]=100;
priceArray[8][1]=200;
priceArray[8][2]=300;
priceArray[8][3]=400;
priceArray[8][4]=400;
priceArray[8][5]=500;

priceArray[9][0]=100;
priceArray[9][1]=200;
priceArray[9][2]=300;
priceArray[9][3]=400;
priceArray[9][4]=400;
priceArray[9][5]=500;

priceArray[10][0]=100;
priceArray[10][1]=200;
priceArray[10][2]=300;
priceArray[10][3]=400;
priceArray[10][4]=400;
priceArray[10][5]=500;

priceArray[11][0]=100;
priceArray[11][1]=200;
priceArray[11][2]=300;
priceArray[11][3]=400;
priceArray[11][4]=400;
priceArray[11][5]=500;

priceArray[12][0]=100;
priceArray[12][1]=200;
priceArray[12][2]=300;
priceArray[12][3]=400;
priceArray[12][4]=400;
priceArray[12][5]=500;

priceArray[13][0]=100;
priceArray[13][1]=200;
priceArray[13][2]=300;
priceArray[13][3]=400;
priceArray[13][4]=400;
priceArray[13][5]=500;

priceArray[14][0]=100;
priceArray[14][1]=200;
priceArray[14][2]=300;
priceArray[14][3]=400;
priceArray[14][4]=400;
priceArray[14][5]=500;


























